@echo off
title AutomatiQA Certificate Setup
echo =================================================================
echo        AutomatiQA Local Agent Certificate Trust Setup
echo =================================================================
echo.
echo Installing AutomatiQA Certificate into CurrentUser Trusted Root Store...
certutil -addstore -user "Root" "%~dp0automatiqa-ca.crt"
if %ERRORLEVEL% equ 0 (
  echo.
  echo [SUCCESS] Certificate installed and trusted!
  echo You can now connect securely over wss://localhost:9334 with zero SSL warnings.
) else (
  echo.
  echo [NOTE] Automatic certutil installation returned code %ERRORLEVEL%.
  echo You can also authorize SSL by visiting https://localhost:9334/status in Chrome.
)
echo.
pause
