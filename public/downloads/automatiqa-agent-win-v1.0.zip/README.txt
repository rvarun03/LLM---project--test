AutomatiQA Local Web Recording Agent (Windows)
==============================================

QUICK START INSTRUCTIONS:
1. Double-click "start-agent.bat" or "automatiqa-agent-win-v1.0.exe".
2. If Windows SmartScreen displays "Windows protected your PC":
   -> Click "More info"
   -> Click "Run anyway"
3. The agent will start listening on ws://localhost:9333 (and http://localhost:9333).
4. A log file "automatiqa-agent.log" is automatically saved in this folder.
5. Return to your AutomatiQA Web Performance page:
   You will see "Agent detected" with a green checkmark!
6. Enter your Target URL and click "Start Record".
   Chromium will launch to record your network traffic and user interactions.

TROUBLESHOOTING:
- Port 9333 busy: Close any other running AutomatiQA agents or check Task Manager.
- Check "automatiqa-agent.log" in this directory for detailed error diagnostics.
- For assistance, contact support at vinuta@qaoncloud.com
