AutomatiQA Local Web Recording Agent (macOS)
============================================

QUICK START INSTRUCTIONS:
1. Double-click "start-agent.command" or run in Terminal:
   chmod +x ./automatiqa-agent-mac-v1.0
   ./automatiqa-agent-mac-v1.0

2. If macOS Gatekeeper prevents opening ("unidentified developer"):
   Method A:
   - In Finder, Right-click (or Control-click) "automatiqa-agent-mac-v1.0"
   - Click "Open" from the context menu
   - In the confirmation dialog, click "Open"
   
   Method B (Terminal):
   - Open Terminal in this folder and run:
     xattr -d com.apple.quarantine automatiqa-agent-mac-v1.0
     ./automatiqa-agent-mac-v1.0

3. Keep the agent running in the background.
4. Return to AutomatiQA Web Performance -> Record & Capture tab.
   You will see "Agent detected" and can click "Start Record"!
