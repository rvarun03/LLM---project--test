/**
 * AutomatiQA Web Performance Agent Bridge - Content Script
 *
 * Facilitates two-way communication between the Web Performance Testing page in AI Studio
 * and the background worker connecting to wss://localhost:9334.
 */

(function () {
  const NAMESPACE = 'automatiqa-web-performance';
  const PAGE_SOURCE = 'automatiqa-web-perf-page';
  const BRIDGE_SOURCE = 'automatiqa-web-perf-bridge';

  // Mark window presence
  try {
    window.__AUTOMATIQA_WEB_PERF_BRIDGE__ = {
      installed: true,
      version: '1.0.0',
      timestamp: Date.now()
    };
  } catch (e) {}

  let bridgePort = null;

  function initBridgePort() {
    try {
      bridgePort = chrome.runtime.connect({ name: NAMESPACE });

      bridgePort.onMessage.addListener((msg) => {
        if (!msg || msg.namespace !== NAMESPACE) return;
        // Relay to window
        window.postMessage({
          ...msg,
          namespace: NAMESPACE,
          source: BRIDGE_SOURCE
        }, '*');
      });

      bridgePort.onDisconnect.addListener(() => {
        bridgePort = null;
        // Post disconnect to page
        window.postMessage({
          namespace: NAMESPACE,
          source: BRIDGE_SOURCE,
          type: 'bridge_status',
          bridgeInstalled: true,
          agentStatus: 'disconnected'
        }, '*');
      });
    } catch (err) {
      bridgePort = null;
    }
  }

  initBridgePort();

  // Listen for messages from background script broadcast
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.namespace === NAMESPACE) {
      window.postMessage({
        ...msg,
        namespace: NAMESPACE,
        source: BRIDGE_SOURCE
      }, '*');
    }
  });

  // Listen for messages from the AI Studio Web Performance Testing page
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;

    const data = event.data;
    if (data.namespace !== NAMESPACE || data.source !== PAGE_SOURCE) {
      return;
    }

    const action = data.action;
    const payload = data.payload || {};

    if (action === 'ping_bridge') {
      // Immediate direct pong
      window.postMessage({
        namespace: NAMESPACE,
        source: BRIDGE_SOURCE,
        type: 'bridge_status',
        bridgeInstalled: true,
        bridgeVersion: '1.0.0',
        timestamp: Date.now()
      }, '*');
    }

    // Forward action to background worker
    if (!bridgePort) {
      initBridgePort();
    }

    if (bridgePort) {
      try {
        bridgePort.postMessage({
          namespace: NAMESPACE,
          action: action,
          payload: payload
        });
      } catch (e) {
        // Fallback to one-off message
        chrome.runtime.sendMessage({
          namespace: NAMESPACE,
          action: action,
          payload: payload
        }, (response) => {
          if (chrome.runtime.lastError) return;
          if (response) {
            window.postMessage({
              ...response,
              namespace: NAMESPACE,
              source: BRIDGE_SOURCE
            }, '*');
          }
        });
      }
    } else {
      chrome.runtime.sendMessage({
        namespace: NAMESPACE,
        action: action,
        payload: payload
      }, (response) => {
        if (chrome.runtime.lastError) return;
        if (response) {
          window.postMessage({
            ...response,
            namespace: NAMESPACE,
            source: BRIDGE_SOURCE
          }, '*');
        }
      });
    }
  });

  // Initial announcement to page
  window.postMessage({
    namespace: NAMESPACE,
    source: BRIDGE_SOURCE,
    type: 'bridge_status',
    bridgeInstalled: true,
    bridgeVersion: '1.0.0'
  }, '*');
})();
