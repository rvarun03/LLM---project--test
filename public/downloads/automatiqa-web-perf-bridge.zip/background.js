/**
 * AutomatiQA Web Performance Agent Bridge - Background Service Worker
 *
 * Architecture:
 * Google AI Studio Web Performance UI
 *         ↓ (window.postMessage)
 * Content Script (content.js)
 *         ↓ (chrome.runtime messaging / Port)
 * Background Worker (background.js)
 *         ↓ (wss://localhost:9334)
 * Local AutomatiQA Recording Agent
 */

const AGENT_WS_URL = 'wss://localhost:9334';
const AGENT_HTTPS_URL = 'https://localhost:9334/status';
const AGENT_HTTP_URL = 'http://localhost:9333/status';
const NAMESPACE = 'automatiqa-web-performance';

let agentSocket = null;
let isConnecting = false;
let agentStatus = 'disconnected'; // 'connected' | 'disconnected' | 'untrusted' | 'connecting'
let agentVersion = null;
let lastError = null;

// Track active content script ports
const activePorts = new Set();

// Listen for tab updates to auto-reconnect when user approves SSL on localhost:9334
try {
  if (chrome.tabs && chrome.tabs.onUpdated) {
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === 'complete' && tab.url && tab.url.includes('localhost:9334')) {
        console.log('[WebPerfBridge] Detected localhost:9334 tab update, reconnecting WSS...');
        setTimeout(() => {
          connectAgentWebSocket();
        }, 300);
      }
    });
  }
} catch (e) {}

/**
 * Broadcast message to all active content script listeners and open ports
 */
function broadcastToPage(payload) {
  const message = {
    namespace: NAMESPACE,
    source: 'automatiqa-web-perf-bridge',
    timestamp: Date.now(),
    ...payload
  };

  // 1. Post to active long-lived connection ports
  for (const port of activePorts) {
    try {
      port.postMessage(message);
    } catch (e) {
      activePorts.delete(port);
    }
  }

  // 2. Broadcast via chrome.tabs to all matching frames
  try {
    chrome.tabs.query({}, (tabs) => {
      if (chrome.runtime.lastError || !tabs) return;
      tabs.forEach((tab) => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, message).catch(() => {});
        }
      });
    });
  } catch (e) {
    // Ignore context invalidation
  }
}

/**
 * Connect to Local Agent via WebSocket (wss://localhost:9334)
 */
function connectAgentWebSocket(onConnectCallback) {
  if (agentSocket && (agentSocket.readyState === WebSocket.OPEN || agentSocket.readyState === WebSocket.CONNECTING)) {
    if (agentSocket.readyState === WebSocket.OPEN && onConnectCallback) {
      onConnectCallback(agentSocket);
    }
    return;
  }

  isConnecting = true;
  agentStatus = 'connecting';
  broadcastToPage({ type: 'bridge_agent_status', status: 'connecting' });

  try {
    const ws = new WebSocket(AGENT_WS_URL);
    agentSocket = ws;

    ws.onopen = () => {
      isConnecting = false;
      agentStatus = 'connected';
      lastError = null;
      console.log('[WebPerfBridge] Connected to AutomatiQA Agent at', AGENT_WS_URL);

      // Probe agent status
      try {
        ws.send(JSON.stringify({ action: 'check_status' }));
      } catch (e) {}

      broadcastToPage({
        type: 'bridge_agent_status',
        status: 'connected',
        version: agentVersion
      });

      if (onConnectCallback) {
        onConnectCallback(ws);
      }
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Cache version if available
        if (data.type === 'agent_status' && data.version) {
          agentVersion = data.version;
        }

        // Relay agent message directly to the web performance page
        broadcastToPage(data);
      } catch (err) {
        console.warn('[WebPerfBridge] Failed to parse agent message:', err);
      }
    };

    ws.onerror = (event) => {
      console.warn('[WebPerfBridge] Agent WebSocket error:', event);
      // If error occurs, probe agent status to distinguish between untrusted SSL and offline agent
      probeAgentHttps();
    };

    ws.onclose = (event) => {
      isConnecting = false;
      agentStatus = 'disconnected';
      if (agentSocket === ws) {
        agentSocket = null;
      }
      broadcastToPage({
        type: 'bridge_agent_status',
        status: 'disconnected',
        code: event.code,
        reason: event.reason || 'Agent connection closed'
      });
    };
  } catch (err) {
    isConnecting = false;
    agentStatus = 'disconnected';
    lastError = err.message || String(err);
    probeAgentHttps();
  }
}

/**
 * Probe Agent HTTPS & HTTP status endpoints to distinguish between untrusted SSL and offline agent
 */
async function probeAgentHttps() {
  // 1. First probe HTTPS port 9334
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);
    const res = await fetch(AGENT_HTTPS_URL, {
      signal: controller.signal,
      cache: 'no-store'
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const json = await res.json().catch(() => ({}));
      if (json.version) agentVersion = json.version;
      agentStatus = 'connected';
      broadcastToPage({
        type: 'bridge_agent_status',
        status: 'connected',
        version: agentVersion
      });
      return;
    }
  } catch (err) {
    const errStr = String(err).toLowerCase();
    if (errStr.includes('cert') || errStr.includes('security') || errStr.includes('authority') || errStr.includes('ssl')) {
      agentStatus = 'untrusted';
      broadcastToPage({
        type: 'bridge_agent_status',
        status: 'untrusted',
        message: 'Agent detected but self-signed certificate not trusted. Visit https://localhost:9334/status to approve.'
      });
      return;
    }
  }

  // 2. Fallback probe HTTP port 9333 to see if agent is running locally but WSS certificate needs trust
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1500);
    const res = await fetch(AGENT_HTTP_URL, {
      signal: controller.signal,
      cache: 'no-store'
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const json = await res.json().catch(() => ({}));
      if (json.version) agentVersion = json.version;
      // Agent is running, but WSS on 9334 threw cert error
      agentStatus = 'untrusted';
      broadcastToPage({
        type: 'bridge_agent_status',
        status: 'untrusted',
        version: agentVersion,
        message: 'Agent is running on localhost, but WSS certificate needs 1-click authorization.'
      });
      return;
    }
  } catch (_) {}

  agentStatus = 'disconnected';
  broadcastToPage({
    type: 'bridge_agent_status',
    status: 'disconnected',
    message: 'AutomatiQA Agent is not running on localhost:9334.'
  });
}

/**
 * Helper to open the SSL authorization tab
 */
function openSslAuthTab() {
  try {
    chrome.tabs.create({ url: 'https://localhost:9334/status' }, (tab) => {
      console.log('[WebPerfBridge] Opened SSL Authorization tab:', tab?.id);
    });
  } catch (e) {
    console.warn('[WebPerfBridge] Failed to open SSL tab:', e);
  }
}

/**
 * Handle messages from Content Script
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.namespace !== NAMESPACE) {
    return false;
  }

  const { action, payload } = message;

  switch (action) {
    case 'ping_bridge':
    case 'check_status':
      // Respond with current bridge & agent status
      if (!agentSocket || agentSocket.readyState !== WebSocket.OPEN) {
        connectAgentWebSocket();
      } else {
        try {
          agentSocket.send(JSON.stringify({ action: 'check_status' }));
        } catch (e) {}
      }

      sendResponse({
        namespace: NAMESPACE,
        source: 'automatiqa-web-perf-bridge',
        type: 'bridge_status',
        bridgeInstalled: true,
        bridgeVersion: '1.0.0',
        agentStatus: agentStatus,
        agentVersion: agentVersion
      });
      return true;

    case 'authorize_ssl':
    case 'open_ssl_auth':
      openSslAuthTab();
      sendResponse({ success: true, status: 'opened_auth_tab' });
      return true;

    case 'start_record':
      connectAgentWebSocket((ws) => {
        try {
          ws.send(JSON.stringify({
            action: 'start_record',
            url: payload?.url,
            sessionId: payload?.sessionId
          }));
          sendResponse({ success: true, status: 'recording_requested' });
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
      });
      return true;

    case 'stop_record':
      if (agentSocket && agentSocket.readyState === WebSocket.OPEN) {
        try {
          agentSocket.send(JSON.stringify({
            action: 'stop_record',
            sessionId: payload?.sessionId,
            reason: payload?.reason || 'User stopped recording'
          }));
          sendResponse({ success: true, status: 'stop_requested' });
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
      } else {
        sendResponse({ success: false, error: 'Agent WebSocket is not open' });
      }
      return true;

    case 'send_agent_command':
      if (agentSocket && agentSocket.readyState === WebSocket.OPEN) {
        try {
          agentSocket.send(JSON.stringify(payload));
          sendResponse({ success: true });
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
      } else {
        sendResponse({ success: false, error: 'Agent WebSocket is not open' });
      }
      return true;

    default:
      sendResponse({ error: `Unknown action: ${action}` });
      return false;
  }
});

/**
 * Handle persistent port connections from content script
 */
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === NAMESPACE) {
    activePorts.add(port);

    // Initial status broadcast on connect
    port.postMessage({
      namespace: NAMESPACE,
      source: 'automatiqa-web-perf-bridge',
      type: 'bridge_status',
      bridgeInstalled: true,
      bridgeVersion: '1.0.0',
      agentStatus: agentStatus,
      agentVersion: agentVersion
    });

    port.onDisconnect.addListener(() => {
      activePorts.delete(port);
    });

    port.onMessage.addListener((msg) => {
      if (msg.action === 'ping_bridge' || msg.action === 'check_status') {
        if (!agentSocket || agentSocket.readyState !== WebSocket.OPEN) {
          connectAgentWebSocket();
        }
        port.postMessage({
          namespace: NAMESPACE,
          source: 'automatiqa-web-perf-bridge',
          type: 'bridge_status',
          bridgeInstalled: true,
          bridgeVersion: '1.0.0',
          agentStatus: agentStatus,
          agentVersion: agentVersion
        });
      } else if (msg.action === 'authorize_ssl' || msg.action === 'open_ssl_auth') {
        openSslAuthTab();
      } else if (msg.action === 'start_record') {
        connectAgentWebSocket((ws) => {
          ws.send(JSON.stringify({
            action: 'start_record',
            url: msg.payload?.url,
            sessionId: msg.payload?.sessionId
          }));
        });
      } else if (msg.action === 'stop_record') {
        if (agentSocket && agentSocket.readyState === WebSocket.OPEN) {
          agentSocket.send(JSON.stringify({
            action: 'stop_record',
            sessionId: msg.payload?.sessionId,
            reason: msg.payload?.reason
          }));
        }
      }
    });
  }
});

// Auto-connect on startup
connectAgentWebSocket();
