#!/usr/bin/env bash
echo "================================================================="
echo "       AutomatiQA Local Agent Certificate Trust Setup"
echo "================================================================="
echo ""
CERT_FILE="$(dirname "$0")/automatiqa-ca.crt"
if [[ "$OSTYPE" == "darwin"* ]]; then
  echo "Installing certificate into macOS user keychain..."
  security add-trusted-cert -d -r trustRoot -k ~/Library/Keychains/login.keychain "$CERT_FILE" 2>/dev/null && echo "[SUCCESS] Certificate trusted on macOS!" || echo "Note: Visit https://localhost:9334/status in Chrome to authorize directly."
elif command -v trust &>/dev/null; then
  trust anchor --store "$CERT_FILE" 2>/dev/null && echo "[SUCCESS] Certificate trusted via trust anchor!" || echo "Note: Visit https://localhost:9334/status in Chrome to authorize directly."
else
  echo "Please visit https://localhost:9334/status in Chrome to authorize directly."
fi
echo ""
